#ifndef _RTC__H
#define _RTC__H

#include "stm32f10x.h"

void RTC_Configuration(void);
void Time_Display(void);

void RTC_IRQHandler(void);


#endif


