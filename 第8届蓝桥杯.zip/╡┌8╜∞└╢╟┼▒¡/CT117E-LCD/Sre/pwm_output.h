#ifndef __PWM_OUTPUT_H
#define	__PWM_OUTPUT_H

#include "stm32f10x.h"

 void TIM2_Mode_Config(u16 arr,u16 psc,uint32_t CCR_Val,uint32_t CCR_Vall);	
#endif 

