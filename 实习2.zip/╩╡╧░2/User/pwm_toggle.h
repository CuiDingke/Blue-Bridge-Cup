#ifndef __PWM_TOGGLE_H
#define	__PWM_TOGGLE_H

#include "stm32f10x.h"
void toggle_Config(void);

#endif
